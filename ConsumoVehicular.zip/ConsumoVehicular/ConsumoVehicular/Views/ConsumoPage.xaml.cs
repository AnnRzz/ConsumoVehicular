using ConsumoVehicular.ViewModels;

namespace ConsumoVehicular.Views
{
    public partial class ConsumoPage : ContentPage
    {
        public ConsumoPage()
        {
            InitializeComponent();

            BindingContext = new RecorridoViewModel();
        }
    }
}