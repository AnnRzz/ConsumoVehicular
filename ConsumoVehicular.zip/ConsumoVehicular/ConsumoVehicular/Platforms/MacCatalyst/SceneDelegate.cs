using Foundation;

namespace ConsumoVehicular
{
    [Register("SceneDelegate")]
    public class SceneDelegate : MauiUISceneDelegate
    {
    }
}
