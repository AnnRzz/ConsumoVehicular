﻿using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Globalization;
using Microsoft.Maui.Controls;
using ConsumoVehicular.Models;

namespace ConsumoVehicular.ViewModels
{
    public class RecorridoViewModel : INotifyPropertyChanged
    {
        private string _distancia = "";
        private string _litros = "";

        private string _rendimiento = "";
        private string _categoria = "";
        private string _error = "";

        public event PropertyChangedEventHandler? PropertyChanged;

        public Command CalcularCommand { get; }

        public RecorridoViewModel()
        {
            CalcularCommand = new Command(RealizarCalculo);
        }

        public string Distancia
        {
            get { return _distancia; }
            set
            {
                _distancia = value;
                OnPropertyChanged();
            }
        }

        public string Litros
        {
            get { return _litros; }
            set
            {
                _litros = value;
                OnPropertyChanged();
            }
        }

        public string Rendimiento
        {
            get { return _rendimiento; }
            set
            {
                _rendimiento = value;
                OnPropertyChanged();
            }
        }

        public string Categoria
        {
            get { return _categoria; }
            set
            {
                _categoria = value;
                OnPropertyChanged();
            }
        }

        public string Error
        {
            get { return _error; }
            set
            {
                _error = value;
                OnPropertyChanged();
            }
        }

        private void RealizarCalculo()
        {
            Rendimiento = "";
            Categoria = "";
            Error = "";

            if (!ValidarDato(Distancia, "los kilómetros",
                out decimal km))
                return;

            if (!ValidarDato(Litros, "los litros",
                out decimal litros))
                return;

            DatosRecorrido recorrido = new DatosRecorrido();

            recorrido.DistanciaKm = km;
            recorrido.CombustibleLitros = litros;

            decimal resultado = recorrido.ObtenerRendimiento();

            Rendimiento = resultado.ToString(
                "F2", CultureInfo.CurrentCulture);

            if (resultado < 10)
            {
                Categoria = "Bajo";
            }
            else if (resultado < 15)
            {
                Categoria = "Medio";
            }
            else
            {
                Categoria = "Alto";
            }
        }

        private bool ValidarDato(
            string dato,
            string nombre,
            out decimal valor)
        {
            valor = 0;

            if (string.IsNullOrWhiteSpace(dato) ||
                !decimal.TryParse(dato, NumberStyles.Number,
                CultureInfo.CurrentCulture, out valor))
            {
                Error = "Ingresa un número válido para " + nombre + ".";
                return false;
            }

            if (valor <= 0)
            {
                Error = "El valor de " + nombre +
                        " debe ser mayor que cero.";
                return false;
            }

            return true;
        }

        private void OnPropertyChanged(
            [CallerMemberName] string nombre = "")
        {
            PropertyChanged?.Invoke(
                this, new PropertyChangedEventArgs(nombre));
        }
    }
}