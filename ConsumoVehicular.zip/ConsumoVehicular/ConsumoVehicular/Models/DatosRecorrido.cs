﻿namespace ConsumoVehicular.Models
{
    public class DatosRecorrido
    {
        public decimal DistanciaKm { get; set; }

        public decimal CombustibleLitros { get; set; }

        public decimal ObtenerRendimiento()
        {
            return DistanciaKm / CombustibleLitros;
        }
    }
}